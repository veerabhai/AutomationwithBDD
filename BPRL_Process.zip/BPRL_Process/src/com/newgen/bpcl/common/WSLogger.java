package com.newgen.bpcl.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WSLogger {

	private static final Logger serviceLogger = LogManager.getLogger("ServiceLogger");
	private static final Logger errorLogger   = LogManager.getLogger("ErrorLogger");
	private static final Logger xmlLogger     = LogManager.getLogger("XMLLogger");

	public static void servicelog(String strLog) {
		serviceLogger.info(strLog);
	}

	public static void errorlog(String strLog) {
		errorLogger.error(strLog);
	}

	public static void XMLlog(String strLog) {
		xmlLogger.info(strLog);
	}

	public static void integrationLog(String strLog) {
		serviceLogger.info(strLog);
	}

}
