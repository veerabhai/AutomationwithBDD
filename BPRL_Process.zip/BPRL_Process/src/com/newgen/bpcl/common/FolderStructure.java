
package com.newgen.bpcl.common;

import java.util.ArrayList;
import java.util.List;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormCallBroker;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.dmsapi.DMSXmlResponse;

public class FolderStructure {
	WSLogger log = new WSLogger();
	ApiCalls api = new ApiCalls();
	static InitConfigProp initconfigprop = new InitConfigProp();
	String sInputXml = null;
	String sOutputXml = null;
	String serverIp = "";
	int jtsPort;
	DMSXmlResponse xmlResponse = null;
	String resp = "";

	@SuppressWarnings("static-access")
	public String FolderStructureMovement(IFormReference iformref,String sessionId,String department,String country,String asset, String documenttype,String year,
		String winame) {
		String pid = iformref.getObjGeneralData().getM_strProcessInstanceId();
		List<String> docIndex = new ArrayList<>();
		List<String> docIndex1 = new ArrayList<>();
		String stat = null;
		try {

			//create Root folder for BPRL Services
			stat = checkFolderStatus(iformref,"BPRL","0");
			String foldIndex = "";
			if(stat.equalsIgnoreCase("N")) {
				foldIndex = createFolderWithSession(sessionId, "BPRL", "0");
				log.servicelog("createFolderWithSession function ends for BPRL "+foldIndex );
				//api.setACL(iformref, sessionId, "F", foldIndex);
				api.ngoChangeFolderProperty(sessionId, foldIndex,"BPRL");
				//api.setACL(iformref, sessionId, "F", foldIndex);
			}else {
				foldIndex = getFoldIndex(iformref, "BPRL","0");
			}
			if (foldIndex == null) return "BPRL folder not created";
			log.servicelog("createFolderWithSession function starts for department:- " +department);

			//for Department
			if (department == null) return "Invalid Department";
			log.servicelog("createFolderWithSession function starts for department:- " +department);
			stat = checkFolderStatus(iformref,department,foldIndex);
			String foldIndex1 = "";
			if(stat.equalsIgnoreCase("N")) {
				foldIndex1 = createFolderWithSession(sessionId, department, foldIndex);
				log.servicelog("createFolderWithSession function ends for BPRLServices "+foldIndex1 +"department--" +department );
				//api.setACL(iformref, sessionId, "F", foldIndex1);
				api.ngoChangeFolderProperty(sessionId, foldIndex1,department);
				//api.setACL(iformref, sessionId, "F", foldIndex1);
			}else {
				foldIndex1 = getFoldIndex(iformref, department,foldIndex);
			}
			if (foldIndex1 == null) return "department folder not created";
			log.servicelog("createFolderWithSession function starts for country:- " +country);

			//For Country
			stat = checkFolderStatus(iformref,country,foldIndex1);
			String foldIndex2 = "";
			if(stat.equalsIgnoreCase("N")) {
				foldIndex2 = createFolderWithSession(sessionId, country, foldIndex1);
				log.servicelog("createFolderWithSession function ends for BPRLServices "+foldIndex2 +"country--" +country );
				//api.setACL(iformref, sessionId, "F", foldIndex2);
				api.ngoChangeFolderProperty(sessionId, foldIndex2,country);
				//api.setACL(iformref, sessionId, "F", foldIndex2);
			}else {
				foldIndex2 = getFoldIndex(iformref, country, foldIndex1);
			}
			if (foldIndex2 == null) return "State folder not created";
			log.servicelog("createFolderWithSession function starts for documenttype:- " +documenttype);
          
			//For Asset
			stat = checkFolderStatus(iformref,asset,foldIndex2);
			String foldIndex3 = "";
			if(stat.equalsIgnoreCase("N")) {
				foldIndex3 = createFolderWithSession(sessionId, asset, foldIndex2);
				log.servicelog("createFolderWithSession function ends for BPRLServices "+foldIndex2 +"asset--" +asset );
				//api.setACL(iformref, sessionId, "F", foldIndex2);
				api.ngoChangeFolderProperty(sessionId, foldIndex3,asset);
				//api.setACL(iformref, sessionId, "F", foldIndex2);
			}else {
				foldIndex3 = getFoldIndex(iformref, country, foldIndex2);
			}
			if (foldIndex3 == null) return "State folder not created";
			log.servicelog("createFolderWithSession function starts for asset:- " +asset);
			
			
			//For Year
			stat = checkFolderStatus(iformref,year,foldIndex3);
			String foldIndex4 = "";
			if(stat.equalsIgnoreCase("N")) {
				foldIndex4 = createFolderWithSession(sessionId, year, foldIndex3);
				log.servicelog("createFolderWithSession function ends for BPRLServices "+foldIndex3 +"year--" +year );
				//api.setACL(iformref, sessionId, "F", foldIndex3);
				api.ngoChangeFolderProperty(sessionId, foldIndex4,year);
				//api.setACL(iformref, sessionId, "F", foldIndex3);
			}else {
				foldIndex4 = getFoldIndex(iformref, year, foldIndex3);
			}
			if (foldIndex4 == null) return "process folder not created";
			log.servicelog("createFolderWithSession function starts for year:- " +year);
//			//For  Document type
			stat = checkFolderStatus(iformref,documenttype,foldIndex4);
			String foldIndex5 = "";
			if(stat.equalsIgnoreCase("N")) {
				foldIndex5 = createFolderWithSession(sessionId, documenttype, foldIndex4);
				log.servicelog("createFolderWithSession function ends for SharedServices "+foldIndex5 +"documenttype--" +documenttype );
				//api.setACL(iformref, sessionId, "F", foldIndex3);
				api.ngoChangeFolderProperty(sessionId, foldIndex5,documenttype);
				//api.setACL(iformref, sessionId, "F", foldIndex3);
			}else {
				foldIndex5 = getFoldIndex(iformref, documenttype, foldIndex4);
			}
			if (foldIndex5 == null) return "documenttype folder not created";
			log.servicelog("createFolderWithSession function starts for documenttype:- " +documenttype);

			String finalFolderIndex = "";
		//	if(period != null && !period.equalsIgnoreCase("")) {
				finalFolderIndex= foldIndex5;
//			}
//			else {
//				finalFolderIndex=foldIndex6;
//			}

			String pidfolderIndex = getfoldFromDb(iformref,pid);
			log.servicelog("getfoldFromDb function ends"+pidfolderIndex+ "pid-- " +pid);
			if (pidfolderIndex == null || pidfolderIndex.isEmpty()) {
				log.servicelog("pid folder index is: "+pidfolderIndex+ "pid-- " +pid);
				return "Folder Index not found";
			}

			docIndex1 = api.nGOGetDocumentList(pidfolderIndex, sessionId);
			log.servicelog("doc index in pid folder is: "+docIndex1);
			String owner = iformref.getObjGeneralData().getM_strUserName();
			//String owner = initconfigprop.getProperty("SSfolderowner");
			log.servicelog("logged in userindex is: "+owner);
			String resp = updateDocumentProperties(iformref, docIndex1,sessionId,department,country,asset,documenttype,year,
					winame,owner);

			if(resp.equalsIgnoreCase("Success")) {
				Result result = nGOModifiedGetDocumentList(iformref,pidfolderIndex, sessionId);
				log.servicelog("nGOModifiedGetDocumentList function ends"+result+  "pid-- " +pid);
				if (result != null) {
					docIndex = result.getList1();   //it has the list of docids which are present in pid folder
				}
				if (docIndex != null && !docIndex.isEmpty()) {
					log.servicelog("copyDocumentsWithSession function starts for Y"+docIndex+ "pid-- " +pid);
					String sessionIdforcopydoc = api.connectCabinet(iformref, "docid", "docvalidator");
					log.servicelog("sessionIdforcopydoc is: " + sessionIdforcopydoc);
					copyDocumentsWithSession(sessionIdforcopydoc, pidfolderIndex, docIndex, finalFolderIndex, "Y");
					log.servicelog("copyDocumentsWithSession function ends for Y"+  "pid-- " +pid);
				}

				//change the owner of docs present in PID folder
				String resp1 = updateDocumentPropertiesaftercomplete(iformref, docIndex1,sessionId,"","","","","","");
				log.servicelog("response after updating PID folder doc properties " +resp1);
				return Constant.SUCCESS;
			}
			else {
				return Constant.ERROR;
			}
		}
		catch(Exception e) {
			return Constant.ERROR;
		}
	}

	@SuppressWarnings("static-access")
	private String createFolderWithSession(String sessionId, String folderName, String parentIndex) {
		log.servicelog("Inside createFolderWithSession");
		return api.ngoAddFolder(sessionId, folderName, parentIndex);
	}

	@SuppressWarnings({ "static-access", "unchecked" })
	public String getfoldFromDb(IFormReference iformref,String pid){
		String folderIndex = null;
		List<List<String>> outputList = null;
		log.servicelog("pid in getfolderfromDB is :" +pid);
		String query = "select folderindex from PDBFolder where name='" + pid + "'";
		log.servicelog("getfolderfromDB query is:" +query);
		try {
			outputList = iformref.getDataFromDB(query);
			log.servicelog("pid in getfolderfromDB query output is:" +outputList);
			if(outputList !=null && !outputList.isEmpty()) {
				folderIndex = outputList.get(0).get(0);
			}
		}catch(Exception e) {
			log.errorlog("Exception in populatestate is:" + e);
		}
		return folderIndex;
	}


	@SuppressWarnings("static-access")
	public Result nGOModifiedGetDocumentList(IFormReference iformref, String pidfolderIndex, String sessionId) {
		NGXmlList listXml = null;
		List<String> docIndex = new ArrayList<>();
		StringBuilder strInputXml = new StringBuilder();
		try {
			strInputXml.append("<?xml version=\"1.0\"?>");
			strInputXml.append("<NGOGetDocumentListExt_Input>");
			strInputXml.append("<Option>NGOGetDocumentListExt</Option>");
			strInputXml.append("<CabinetName>").append(initconfigprop.getProperty("databasename"))
			.append("</CabinetName>");
			strInputXml.append("<UserDBId>").append(sessionId).append("</UserDBId>");
			strInputXml.append("<FolderIndex>").append(pidfolderIndex).append("</FolderIndex>");
			strInputXml.append("<ISDocFlag>N</ISDocFlag>");
			/**
			 * Added order by and sort order tag to fetch the latest documents in descending
			 * order
			 */
			//strInputXml.append("<OrderBy>").append(initconfigprop.getProperty("orderby")).append("</OrderBy>");
			//strInputXml.append("<SortOrder>").append(initconfigprop.getProperty("sortorder")).append("</SortOrder>");
			strInputXml.append("<DataAlsoFlag>N</DataAlsoFlag>");
			/** Added a tag PostHookRequired for restricting the impact of posthook */
			strInputXml.append("<PostHookRequired>N</PostHookRequired>");
			strInputXml.append("</NGOGetDocumentListExt_Input>");

			sInputXml = strInputXml.toString();
			log.XMLlog("InputXML of crntfolderIndex NGOGetDocList " + sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml =  IFormCallBroker.execute(sInputXml,serverIp, jtsPort);
			log.XMLlog("OutputXML of crntfolderIndex NGOGetDocList " + sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);
			XMLParser xmlparser = new XMLParser(sOutputXml);

			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {

				listXml = xmlparser.createList("Documents", "Document");

				for (listXml.reInitialize(true); listXml.hasMoreElements(true); listXml.skip(true)) {
					// Extract the base part from dynamicString
					String baseString = listXml.getVal("DocumentName").split("\\(")[0].trim(); // Splits at the first '('
					if (!(("html").equalsIgnoreCase(listXml.getVal("CreatedByAppName"))
							|| ("htm").equalsIgnoreCase(listXml.getVal("CreatedByAppName")))) {
						log.servicelog("LIST OF DOCUMENT AS NO DOC IN DEFAULT FOLDER- "
								+ listXml.getVal("DocumentIndex") + " : " + listXml.getVal("DocumentName"));
						docIndex.add(listXml.getVal("DocumentIndex"));
					}
				}
				return new Result(docIndex);
			} 
		}
		catch (Exception e) {
			log.errorlog("Exception " + e);
		}
		return new Result(docIndex);
	}

	public static class Result {
		private final List<String> list1;

		public Result(List<String> list1) {
			this.list1 = list1;
		}

		public List<String> getList1() {
			return list1;
		}

		@Override
		public String toString() {
			return "Result [list1=" + list1 + "]";
		}
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	public String getTrashIndex(IFormReference iformref,String sessionId){
		String query="";
		String userName = null;
		String destfolderIndex = null;
		List<List<String>> outputList = null;

		log.servicelog("sessionid in getTrashIndex is :" +sessionId);
		query = "select pu.username from PDBCONNECTION as PC inner join PDBUSER as PU on "
				+ "PC.userindex=PU.userindex where randomnumber='" + sessionId + "'";
		log.servicelog("query is:" +query);
		try {
			outputList = iformref.getDataFromDB(query);
			log.servicelog("UserName for sessionId is:" +outputList);
			if(outputList !=null && !outputList.isEmpty()) {
				userName = outputList.get(0).get(0);
				userName = "User_Trash_" + userName;
			}
		}catch(Exception e) {
			log.errorlog("Exception in populatestate is:" + e);
		}
		log.servicelog("userName is:" +userName);

		query = "select folderindex from pdbfolder where name='" + userName + "'";
		log.servicelog("query to get folderindex of trash user is:" +query);
		try {
			outputList = iformref.getDataFromDB(query);
			log.servicelog("folderindex for trash user is:" +outputList);
			if(outputList !=null && !outputList.isEmpty()) {
				destfolderIndex = outputList.get(0).get(0);
			}
		}catch(Exception e) {
			log.errorlog("Exception in populatestate is:" + e);
		}
		return destfolderIndex;
	}

	@SuppressWarnings("static-access")
	private void copyDocumentsWithSession(String sessionId, String pidfolderIndex,
			List<String> docList, String finalFolderIndex, String flag) {
		List<String> documentName = new ArrayList<>();
		if (sessionId != null && docList != null && !docList.isEmpty()) {
			documentName = api.nGOModifiedCopyDocuments(pidfolderIndex, sessionId, docList, finalFolderIndex, flag);
		}
		log.servicelog("Document Name moved successfully " + documentName);
	}

	@SuppressWarnings("static-access")
	private String updateDocumentPropertiesaftercomplete(IFormReference iformref,List<String> docs,String sessionId, String department,String country,String asset, String documenttype,
			 String year,String owner) {
		log.servicelog("Inside updateDocumentPropertiesaftercomplete");

		String resp = "";
		if (docs != null && !docs.isEmpty()) {
			for (String docId : docs) {
				String name="";
				try {
					name = "Document";
				} catch (Exception e) {
					log.errorlog("Exception " + e);
				}
				log.servicelog("Name " + name);				
				resp = api.ngoChangeDocumentProperty(sessionId, docId, department,country,asset, documenttype,year,
						 owner, name,"");
			}
		}
		return resp;
	}

	@SuppressWarnings("static-access")
	private String updateDocumentProperties(IFormReference iformref,List<String> docs,String sessionId, String department,String country,String asset, String documenttype,
		 String year,String winame,String owner) {
		log.servicelog("Inside updateDocumentProperties");

		String resp = "";
		if (docs != null && !docs.isEmpty()) {
			for (String docId : docs) {
				String name="";
				try {
					name = getDocumentName(iformref,docId);
				} catch (Exception e) {
					log.errorlog("Exception " + e);
				}
				log.servicelog("Name " + name);				
				resp = api.ngoChangeDocumentProperty(sessionId, docId, department,country,asset, documenttype, year,winame,
						owner,"");
			}
		}
		return resp;
	}

	@SuppressWarnings({ "static-access", "unchecked" })
	public String getDocumentName(IFormReference iformref,String documentIndex){

		String docname = null;
		String comment = null;
		List<List<String>> outputList = null;
		log.servicelog("documentIndex in getDocumentName is :" +documentIndex);
		String query = "select name, comment from PDBDocument where DocumentIndex='" + documentIndex + "'";
		log.servicelog("getDocumentName query is:" +query);
		try {
			outputList = iformref.getDataFromDB(query);
			log.servicelog("docname and comment in getDocumentName query output is:" +outputList);
			if(outputList !=null && !outputList.isEmpty()) {
				docname = outputList.get(0).get(0);
				comment = outputList.get(0).get(1);
				log.servicelog("docname in getDocumentName is :" +docname);
				log.servicelog("comment in getDocumentName is :" +comment);
			}
		}catch(Exception e) {
			log.errorlog("Exception in populatestate is:" + e);
		}
		return comment;
	}

	@SuppressWarnings({ "static-access", "unchecked" })
	public String checkFolderStatus(IFormReference iformref,String foldername, String parentfolderindex){
		String query = null;
		List<List<String>> outputList = null;
		log.servicelog("foldername in checkFolderStatus is :" +foldername);
		log.servicelog("parentfolderindex in checkFolderStatus is :" +parentfolderindex);
		query = "select name from pdbfolder where name = '"+foldername+"' and parentfolderindex = '"+parentfolderindex+"'";
		log.servicelog("checkFolderStatus query is:" +query);
		try {
			outputList = iformref.getDataFromDB(query);
			log.servicelog("docname and comment in getDocumentName query output is:" +outputList);
			if(outputList !=null && !outputList.isEmpty()) {
				log.servicelog("folder with this name already exist");
				return "Y";
			}
			else {
				log.servicelog("folder with this name not exist");
				return "N";
			}
		}catch(Exception e) {
			log.errorlog("Exception in checkFolderStatus is:" + e);
		}
		return "";
	}

	@SuppressWarnings({ "static-access", "unchecked" })
	public String getFoldIndex(IFormReference iformref, String fieldname, String folderIndex){
		String query = null;
		List<List<String>> outputList = null;
		log.servicelog("fieldname in getFoldIndex is :" +fieldname);
		log.servicelog("folderIndex in getFoldIndex is :" +folderIndex);

		query = "select folderindex from pdbfolder where name = '"+fieldname+"'"
				+ "and parentfolderindex = '"+folderIndex+"'";
		log.servicelog("getFoldIndex query is:" +query);
		try {
			outputList = iformref.getDataFromDB(query);
			log.servicelog("folderindex in getFoldIndex query output is:" +outputList);
			if(outputList !=null && !outputList.isEmpty()) {
				String findex = outputList.get(0).get(0);
				log.servicelog("folder index in getFoldIndex is:" +findex);
				return findex;
			}
			else {
				log.servicelog("folder index with this name not exist");
			}
		}catch(Exception e) {
			log.errorlog("Exception in checkFolderStatus is:" + e);
		}
		return "";
	}

}
