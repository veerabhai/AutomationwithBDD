
package com.newgen.bpcl.common;

import java.util.ArrayList;
import java.util.List;

import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormCallBroker;
import com.newgen.omni.jts.cmgr.NGXmlList;
import com.newgen.omni.jts.cmgr.XMLParser;

public class ApiCalls {
	WSLogger log = new WSLogger();
	static InitConfigProp initconfigprop = new InitConfigProp();
	String sInputXml = null;
	String sOutputXml = null;
	String serverIp = "";
	int jtsPort;
	DMSXmlResponse xmlResponse = null;

	/****
	 * @author shubham.n.gupta
	 * @date 25-09-2025
	 * @param folderName
	 * @param parentIndex
	 * @description NGOAddFolder call to add Folder inside OD
	 * @return
	 */
	@SuppressWarnings("static-access")
	public String ngoAddFolder(String sessionId, String folderName, String parentIndex) {
		log.servicelog("Inside ngoAddFolder" );
		log.servicelog("folderName - "+folderName);
		log.servicelog("parentIndex - "+parentIndex);

		StringBuilder strInputXml = new StringBuilder();
		String folderIndex = "";
		try {
			strInputXml.append("<?xml version=\"1.0\"?>");
			strInputXml.append("<NGOAddFolder_Input>");
			strInputXml.append("<Option>NGOAddFolder</Option>");
			strInputXml.append("<CabinetName>").append(initconfigprop.getProperty("databasename"))
			.append("</CabinetName>");
			strInputXml.append("<UserDBId>").append(sessionId).append("</UserDBId>");
			strInputXml.append("<Folder>");
			strInputXml.append("<ParentFolderIndex>").append(parentIndex).append("</ParentFolderIndex>");
			strInputXml.append("<FolderName>").append(folderName).append("</FolderName>");
			strInputXml.append("<DuplicateName>N</DuplicateName>");
			strInputXml.append("<AccessType>P</AccessType>");
			strInputXml.append("<ImageVolumeIndex>"+initconfigprop.getProperty("SSVolumeID")+"</ImageVolumeIndex>");
			strInputXml.append("<FolderType>G</FolderType>");
			//strInputXml.append("<OwnerIndex>1</OwnerIndex>");       //added by shubham.n.gupta on 28-10-2025 to make supervisor by default owner
			/** Added by shubham.n.gupta for adding FTSflag in addFolder call*/
			strInputXml.append("<EnableFtsFlag>Y</EnableFtsFlag>");
			strInputXml.append("</Folder>");
			strInputXml.append("</NGOAddFolder_Input>");

			sInputXml = strInputXml.toString();

			log.XMLlog("sInputXml NGOAddFolder_Input - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml NGOAddFolder_Output - "+sOutputXml);


			xmlResponse = new DMSXmlResponse(sOutputXml);
			log.servicelog("Status: " +xmlResponse.getVal("Status"));
			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))
					|| ("-50124").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				folderIndex = xmlResponse.getVal("FolderIndex");
			}
			log.servicelog("Final FolderIndex " + folderIndex);
			return folderIndex;
		} catch (Exception e) {
			log.errorlog("Exception " + e);
			return "Exception " + e;
		}
	}

	@SuppressWarnings("static-access")
	public  void getDeleteDocumentExt(String referenceFlag, String docIndex, String sessionId,String parentFolderIndex) {
		log.servicelog("Inside ngoMoveDocument call"+ "docIndex-- " +docIndex );

		StringBuilder delteDocInputXml = new StringBuilder();

		try {
			delteDocInputXml.append("<?xml version=\"1.0\"?>");
			delteDocInputXml.append("<NGODeleteDocumentExt_Input>");
			delteDocInputXml.append("<Option>NGODeleteDocumentExt</Option>");
			delteDocInputXml.append("<UserDBId>" + sessionId + "</UserDBId>");
			delteDocInputXml.append("<CabinetName>" + initconfigprop.getProperty("databasename")   + "</CabinetName>");
			delteDocInputXml.append("<Documents>");
			delteDocInputXml.append("<Document>");
			delteDocInputXml.append("<DocumentIndex>" + docIndex + "</DocumentIndex>");
			delteDocInputXml.append("<ParentFolderIndex>" + parentFolderIndex + "</ParentFolderIndex>");
			delteDocInputXml.append("<ReferenceFlag>"+ referenceFlag + "<ReferenceFlag>");
			delteDocInputXml.append("</Document>");
			delteDocInputXml.append("</Documents>");
			delteDocInputXml.append("</NGODeleteDocumentExt_Input>");

			sInputXml = delteDocInputXml.toString();
			log.XMLlog("sInputXml NGODeleteDocumentExt_Input - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml NGODeleteDocumentExt_Output - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			log.XMLlog("OutpuXML " + sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				log.servicelog("Document Deleted Successfully ");
			}

		} catch (Exception e) {
			log.errorlog("Exception in delteDocoutputXml >> " + e);
			//return status;
		}  finally {
			delteDocInputXml = null;
		}
	}

	@SuppressWarnings("static-access")
	public List<String> nGOGetDocumentList(String folderIndex, String sessionId) {
		log.servicelog("Inside NGOGetDocumentListExt" );
		NGXmlList listXml = null;
		List<String> docIndex = new ArrayList<>();
		StringBuilder strInputXml = new StringBuilder();

		try {
			strInputXml.append("<?xml version=\"1.0\"?>");
			strInputXml.append("<NGOGetDocumentListExt_Input>");
			strInputXml.append("<Option>NGOGetDocumentListExt</Option>");
			strInputXml.append("<CabinetName>").append(initconfigprop.getProperty("databasename").trim())
			.append("</CabinetName>");
			strInputXml.append("<UserDBId>").append(sessionId).append("</UserDBId>");
			strInputXml.append("<FolderIndex>").append(folderIndex).append("</FolderIndex>");
			strInputXml.append("<ISDocFlag>N</ISDocFlag>");
			/**
			 * Added order by and sort order tag to fetch the latest documents in descending
			 * order
			 */
			//strInputXml.append("<OrderBy>").append(GetPropertyValue.getProperty("orderby").trim()).append("</OrderBy>");
			//strInputXml.append("<SortOrder>").append(GetPropertyValue.getProperty("sortorder").trim()).append("</SortOrder>");
			strInputXml.append("<DataAlsoFlag>N</DataAlsoFlag>");
			strInputXml.append("<PostHookRequired>N</PostHookRequired>");
			strInputXml.append("</NGOGetDocumentListExt_Input>");
			sInputXml = strInputXml.toString();

			log.XMLlog("sInputXml NGODeleteDocumentExt_Input - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml NGOGetDocumentListExt_Output - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);
			XMLParser xmlparser = new XMLParser(sOutputXml);
			log.XMLlog("OutputXML of NGOGetDocList " + sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				listXml = xmlparser.createList("Documents", "Document");
				for (listXml.reInitialize(true); listXml.hasMoreElements(true); listXml.skip(true)) {
					// docIndex.add(listXml.getVal("DocumentIndex"));
					log.servicelog("APPNAME - " + listXml.getVal("CreatedByAppName"));
					if (!(("html").equalsIgnoreCase(listXml.getVal("CreatedByAppName"))
							|| ("htm").equalsIgnoreCase(listXml.getVal("CreatedByAppName")))) {
						log.servicelog("LIST OF DOCUMENT - " + listXml.getVal("DocumentIndex")
						+ " : " + listXml.getVal("DocumentName"));
						docIndex.add(listXml.getVal("DocumentIndex"));
					}
				}
			}
			return docIndex;
		} catch (Exception e) {
			log.errorlog("Exception " + e);
		}
		return docIndex;
	}


	@SuppressWarnings("static-access")
	public List<String> nGOModifiedCopyDocuments(String folderIndex, String sessionId, List<String> listXml,
			String destFolDIndex, String duplicateFlag) {
		log.servicelog("Inside nGOModifiedCopyDocuments" );
		NGXmlList listXml1 = null;
		List<String> docName = new ArrayList<>();
		StringBuilder strInputXml = new StringBuilder();
		try {
			strInputXml.append("<?xml version=\"1.0\"?>");
			strInputXml.append("<NGOCopyDocumentExt_Input>");
			strInputXml.append("<Option>NGOCopyDocumentExt</Option>");
			strInputXml.append("<CabinetName>").append(initconfigprop.getProperty("databasename").trim())
			.append("</CabinetName>");
			strInputXml.append("<UserDBId>").append(sessionId).append("</UserDBId>");
			strInputXml.append("<DestFolderIndex>").append(destFolDIndex).append("</DestFolderIndex>");
			strInputXml.append("<DataAlsoFlag>Y</DataAlsoFlag>");
			/**
			 * modified the below parameter value to N from Y to copy the duplicate
			 * documents
			 */
			strInputXml.append("<DuplicateName>").append(duplicateFlag).append("</DuplicateName>");
			//strInputXml.append("<VersionAlso>Y</VersionAlso>");
			strInputXml.append("<Documents>");
			for (String documentIndex : listXml) {
				strInputXml.append("<Document>");
				strInputXml.append("<DocumentIndex>").append(documentIndex).append("</DocumentIndex>");
				strInputXml.append("<ParentFolderIndex>").append(folderIndex).append("</ParentFolderIndex>");
				strInputXml.append("</Document>");
			}
			strInputXml.append("</Documents>");
			strInputXml.append("</NGOCopyDocumentExt_Input>");

			sInputXml = strInputXml.toString();

			log.XMLlog("sInputXml NGOCopyDocumentExt_Input - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml NGOCopyDocumentExt_Output - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);
			XMLParser xmlparser = new XMLParser(sOutputXml);
			log.XMLlog("Output xml of Copy Document:- "+sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				log.servicelog("Documents Moved to location Successfully");
				listXml1 = xmlparser.createList("Documents", "Document");
				for (listXml1.reInitialize(true); listXml1.hasMoreElements(true); listXml1.skip(true)) {
					docName.add(listXml1.getVal("DocumentName"));
				}
			}
			return docName;
		} catch (Exception e) {
			log.errorlog("Exception " + e);
		}
		return null;

	}

	@SuppressWarnings("static-access")
	public String ngoChangeDocumentProperty(String sessionId, String documentIndex, String department,String country,String asset, String documenttype,
		 String year,String winame, String owner, String name) {
		log.servicelog("Inside ngoChangeDocumentProperty" );
		StringBuilder strInputXml = new StringBuilder();

		try {
			strInputXml.append("<? xml version=\"1.0\"?>");
			strInputXml.append("<NGOChangeDocumentProperty_Input>");
			strInputXml.append("<Option>NGOChangeDocumentProperty</Option>");
			strInputXml.append("<CabinetName>" + initconfigprop.getProperty("databasename") + "</CabinetName>");
			strInputXml.append("<UserDBId>" + sessionId + "</UserDBId>");
			strInputXml.append("<Document>");
			strInputXml.append("<DocumentIndex>" + documentIndex + "</DocumentIndex>");
			strInputXml.append("<DocumentName>" + name + "</DocumentName>");
			strInputXml.append("<Owner>" + owner + "</Owner>");
		//	strInputXml.append("<AccessType>" + actype + "</AccessType>");
			strInputXml.append("<DataDefinition>");
			strInputXml.append("<DataDefName>" + initconfigprop.getProperty("DataClassName") + "</DataDefName>");
			strInputXml.append("<DataDefIndex>" + initconfigprop.getProperty("DataDefIndex") + "</DataDefIndex>");

			strInputXml.append("<Fields>");

			strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Department") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("<IndexValue>" + department + "</IndexValue>");
			strInputXml.append("</Field>");
            
			strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Country") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("<IndexValue>" + country + "</IndexValue>");
			strInputXml.append("</Field>");
			
			strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("asset") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("<IndexValue>" + country + "</IndexValue>");
			strInputXml.append("</Field>");
			
			strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("DocumentType") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("<IndexValue>" + documenttype + "</IndexValue>");
			strInputXml.append("</Field>");

//			strInputXml.append("<Field>");
//			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Region") + "</IndexId>");
//			strInputXml.append("<IndexType>S</IndexType>");
//			strInputXml.append("<IndexValue>" + region + "</IndexValue>");
//			strInputXml.append("</Field>");

			strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Year") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("<IndexValue>" + year + "</IndexValue>");
			strInputXml.append("</Field>");

//			strInputXml.append("<Field>");
//			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Date") + "</IndexId>");
//			strInputXml.append("<IndexType>S</IndexType>");
//			strInputXml.append("<IndexValue>" + date + "</IndexValue>");
//			strInputXml.append("</Field>");
//
//			strInputXml.append("<Field>");
//			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Period") + "</IndexId>");
//			strInputXml.append("<IndexType>S</IndexType>");
//			strInputXml.append("<IndexValue>" + period + "</IndexValue>");
//			strInputXml.append("</Field>");
//
//			strInputXml.append("<Field>");
//			strInputXml.append("<IndexId>" + initconfigprop.getProperty("Act") + "</IndexId>");
//			strInputXml.append("<IndexType>S</IndexType>");
//			strInputXml.append("<IndexValue>" + act + "</IndexValue>");
//			strInputXml.append("</Field>");

			strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("WorkitemName") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("<IndexValue>" + winame + "</IndexValue>");
			strInputXml.append("</Field>");

//			strInputXml.append("<Field>");
//			strInputXml.append("<IndexId>" + initconfigprop.getProperty("CaseNomenClature") + "</IndexId>");
//			strInputXml.append("<IndexType>S</IndexType>");
//			strInputXml.append("<IndexValue>" + casenomenclature + "</IndexValue>");
//			strInputXml.append("</Field>");

			/*strInputXml.append("<Field>");
			strInputXml.append("<IndexId>" + initconfigprop.getProperty("DocType") + "</IndexId>");
			strInputXml.append("<IndexType>S</IndexType>");
			strInputXml.append("</Field>");*/

			strInputXml.append("</Fields>");
			strInputXml.append("</DataDefinition>");
			strInputXml.append("</Document>");



			strInputXml.append("</NGOChangeDocumentProperty_Input>");

			sInputXml = strInputXml.toString();
			log.XMLlog("sInputXml NGOChangeDocumentProperty_Input - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml NGOChangeDocumentProperty_Output - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				log.servicelog("Property changed Successfully ");
				return Constant.SUCCESS;
			}
			else {
				log.servicelog("Property changed got failed ");
			}
		} catch (Exception e) {
			log.errorlog("Exception " + e);
			return Constant.ERROR;
		}
		return Constant.SUCCESS;
	}


	@SuppressWarnings("static-access")
	public String completeWI(String sessionID, String pid, String wid) {
		log.servicelog("Inside completeWI" );

		StringBuilder delteDocInputXml = new StringBuilder();
		String status = "";
		try {
			delteDocInputXml.append("<?xml version=\"1.0\"?>");
			delteDocInputXml.append("<WMCompleteWorkitem_Input>");
			delteDocInputXml.append("<Option>WMCompleteWorkitem</Option>");
			delteDocInputXml.append("<EngineName>" + initconfigprop.getProperty("databasename") + "</EngineName>");
			delteDocInputXml.append("<SessionId>" + sessionID + "</SessionId>");
			delteDocInputXml.append("<ProcessInstanceId>" + pid + "</ProcessInstanceId>");
			delteDocInputXml.append("<WorkItemId>" + wid + "</WorkItemId>");
			delteDocInputXml.append("</WMCompleteWorkitem_Input>");

			sInputXml = delteDocInputXml.toString();
			log.XMLlog("sInputXml WMCompleteWorkitem - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml WMCompleteWorkitem_Output - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			log.XMLlog("OutpuXML " + sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("MainCode"))) {
				status = xmlResponse.getVal("MainCode");
				log.servicelog("completeWI call has been executed Successfully ");
			}
			else {
				status = "Error";
			}
		} catch (Exception e) {
			log.errorlog("Exception in delteDocoutputXml >> " + e);
			//return status;
		} 
		return status;
	}

	@SuppressWarnings("static-access")
	public String getWorkiteData(String sessionID, String pid, String wid) {
		log.servicelog("Inside getWorkiteData" );
		StringBuilder delteDocInputXml = new StringBuilder();
		String status = "";
		try {
			delteDocInputXml.append("<?xml version=\"1.0\"?>");
			delteDocInputXml.append("<WFGetWorkitemDataExt_Input>");
			delteDocInputXml.append("<Option>WFGetWorkitemDataExt</Option>");
			delteDocInputXml.append("<EngineName>" + initconfigprop.getProperty("databasename") + "</EngineName>");
			delteDocInputXml.append("<SessionId>" + sessionID + "</SessionId>");
			delteDocInputXml.append("<ProcessInstanceId>" + pid + "</ProcessInstanceId>");
			delteDocInputXml.append("<WorkItemId>" + wid + "</WorkItemId>");
			delteDocInputXml.append("</WFGetWorkitemDataExt_Input>");

			sInputXml = delteDocInputXml.toString();
			log.XMLlog("sInputXml WFGetWorkitemDataExt - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml WFGetWorkitemDataExt - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			log.XMLlog("OutpuXML " + sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("MainCode"))) {
				status = xmlResponse.getVal("MainCode");
				log.servicelog("getWorkiteData call has been executed successfully.");
			}
			else {
				status = "Error";
			}
		} catch (Exception e) {
			log.errorlog("Exception in getWorkiteData >> " + e);
			//return status;
		} 
		return status;
	}


	@SuppressWarnings("static-access")
	public String mailTrigger(IFormReference ifr, String sessionId, String mailTo, String mailFrom,
			String mailcc, String mailSubject, String mailBody, String pid, String wid) {
		log.servicelog("Inside mail trigger API");
		try {

			sInputXml = "<?xml version=\"1.0\"?>" + "<WFAddToMailQueue_Input>"
					+ "<Option>WFAddToMailQueue</Option>"
					+ "<EngineName>" + initconfigprop.getProperty("databasename") + "</EngineName>"
					+ "<SessionId>"+sessionId+"</SessionId>" 
					+ "<ProcessInstanceId>" +pid+ "</ProcessInstanceId>"
					+ "<WorkItemId>" +wid+ "</WorkItemId>" 
					+ "<MailFrom>" +mailFrom+ "</MailFrom>"
					+ "<MailTo>" +mailTo+ "</MailTo>"
					+ "<MailCC>" +mailcc+ "</MailCC>" 
					+ "<MailSubject>" +mailSubject+ "</MailSubject>"
					+ "<MailMessage><html><body>" + mailBody + "</body></html></MailMessage>"
					+ "<Priority>2</Priority>"
					+ "<ContentType>" + Constant.TEXTHTML + "</MailMessage>"
					+ "</WFAddToMailQueue_Input>";

			log.XMLlog("sInputXml mailtrigger - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml WFAddToMailQueue - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			log.XMLlog("OutpuXML " + sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("MainCode"))) {
				log.servicelog("Mail Triggered Successfully ");
			}
			else {
				log.servicelog("Error occured while sending Mail");
				return Constant.ERROR;
			}
		} catch (Exception e) {
			log.errorlog("Exception in mail trigger >> " + e);
			return Constant.ERROR;
		}
		return Constant.SUCCESS;
	}

	@SuppressWarnings("static-access")
	public String setACL(IFormReference ifr, String sessionId, String ObjectType, String ObjectIndex) {
		log.servicelog("Inside setACL API");
		try {

			sInputXml = "<?xml version=\"1.0\"?>" + "<NGOSetACL_Input>"
					+ "<Option>NGOSetACL</Option>"
					+ "<CabinetName>" + initconfigprop.getProperty("databasename") + "</CabinetName>"
					+ "<UserDBId>"+sessionId+"</UserDBId>" 
					+ "<ObjectType>" +ObjectType+ "</ObjectType>"
					+ "<ObjectIndex>" +ObjectIndex+ "</ObjectIndex>" 
					+ "<RetainPreviousACL>Y</RetainPreviousACL>"
					+ "<UserGroupACLs>"
					+ "<UserGroupACL>"
					+ "<UserGroupIndex>" +initconfigprop.getProperty("UserGroupIndex")+ "</UserGroupIndex>" 
					+ "<UserGroupName>" +initconfigprop.getProperty("UserGroupName")+ "</UserGroupName>"
					+ "<UserGroupType>G</UserGroupType>" 
					+ "<Rights>111111</Rights>"
					+ "</UserGroupACL>"
					+ "</UserGroupACLs>"
					+ "</NGOSetACL_Input>";

			log.XMLlog("sInputXml setACL - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml setACL - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			log.XMLlog("OutpuXML " + sOutputXml);
			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				log.servicelog("setACL Successfully ");
			}
			else {
				log.servicelog("Error occured while setACL");
				return Constant.ERROR;
			}
		} catch (Exception e) {
			log.errorlog("Exception in setACL >> " + e);
			return Constant.ERROR;
		}
		return Constant.SUCCESS;
	}

	/**
	 * @author shubham.n.gupta
	 * @param arg0
	 * @return String
	 * @description For establishing a connection in application
	 */
	@SuppressWarnings("static-access")
	public String connectCabinet(IFormReference arg0, String username, String pass) {
		log.servicelog("inside connect cabinet");
		String connectStatus = "";
		String userDBId = "";
		try {
			String inputXml = "<NGOConnectCabinet_Input><Option>NGOConnectCabinet</Option><CabinetName>"
					+ arg0.getCabinetName() + "</CabinetName>" + "<UserName>" + initconfigprop.getProperty(username) + "</UserName>"
					+ "<UserPassword>" + initconfigprop.getProperty(pass) + "</UserPassword>"
					+ "<UserExist>N</UserExist>" + "<MainGroupIndex>0</MainGroupIndex>" + "<UserType>U</UserType>"
					+ "</NGOConnectCabinet_Input>";

			log.XMLlog("Input xml of NGOConnectCabinet:-"+ inputXml);
			String outputXml = IFormCallBroker.execute(inputXml, arg0.getObjGeneralData().getM_strJTSIP(),
					Integer.parseInt(arg0.getObjGeneralData().getM_strJTSPORT()));
			log.XMLlog("Output xml of NGOConnectCabinet:- {}"+ outputXml);
			DMSXmlResponse objResponse = new DMSXmlResponse(outputXml);
			connectStatus = objResponse.getVal("Status");
			log.servicelog("connectStatus= {}"+ connectStatus);
			if (connectStatus.equalsIgnoreCase("0")) {
				userDBId = objResponse.getVal("UserDbId");
				log.servicelog("userDBId= {}"+ userDBId);
				return userDBId;
			} else {
				log.errorlog("connect cabinet failed");
				return "";
			}
		} catch (Exception e) {
			log.errorlog("connect cabinet failed with exception:- "+ e);
		}
		return "";
	}

	/**
	 * @author shubham.n.gupta
	 * @param arg0
	 * @param userDBId
	 * @return String
	 * @description For disconnecting a user from application
	 */
	@SuppressWarnings("static-access")
	public String disconnectCabinet(IFormReference arg0, String userDBId) {
		log.servicelog("inside disconnect cabinet");
		String disconnectStatus = "";
		try {
			String inputXml = "<NGODisconnectCabinet_Input><Option>NGODisconnectCabinet</Option><CabinetName>"
					+ arg0.getCabinetName() + "</CabinetName>" + "<UserDBId>" + userDBId + "</UserDBId>"
					+ "</NGODisconnectCabinet_Input>";

			log.XMLlog("Input xml of NGODisconnectCabinet:- {}"+ inputXml);
			String outputXml = IFormCallBroker.execute(inputXml, arg0.getObjGeneralData().getM_strJTSIP(),
					Integer.parseInt(arg0.getObjGeneralData().getM_strJTSPORT()));
			log.XMLlog("Output xml of NGODisconnectCabinet:- {}"+ outputXml);
			DMSXmlResponse objResponse = new DMSXmlResponse(outputXml);
			disconnectStatus = objResponse.getVal("Status");
			if (disconnectStatus.equalsIgnoreCase("0")) {
				log.servicelog("disconnect cabinet success");
				return "Success";
			} else {
				log.errorlog("disconnect cabinet failed");
				return "Failed";
			}
		} catch (Exception e) {
			log.errorlog("disconnect cabinet failed with exception :- "+ e);
		}
		return "Failed";
	}


	@SuppressWarnings("static-access")
	public String ngoChangeFolderProperty(String sessionId, String folderindex, String foldername) {
		log.servicelog("Inside ngoChangeFolderProperty" );
		StringBuilder strInputXml = new StringBuilder();

		try {
			strInputXml.append("<? xml version=\"1.0\"?>");
			strInputXml.append("<NGOChangeFolderProperty_Input>");
			strInputXml.append("<Option>NGOChangeFolderProperty</Option>");
			strInputXml.append("<CabinetName>" + initconfigprop.getProperty("databasename") + "</CabinetName>");
			strInputXml.append("<UserDBId>" + sessionId + "</UserDBId>");
			strInputXml.append("<Folder>");
			strInputXml.append("<FolderIndex>" + folderindex + "</FolderIndex>");
			strInputXml.append("<FolderName>" + foldername + "</FolderName>");
			strInputXml.append("<EnableFTSFlag>Y</EnableFTSFlag>");
			strInputXml.append("<AccessType>I</AccessType>");
			strInputXml.append("<ImageVolumeIndex>" + initconfigprop.getProperty("SSvolumeindex") + "</ImageVolumeIndex>");
			strInputXml.append("<FolderLock>N</FolderLock>");
			strInputXml.append("<VersionFlag>N</VersionFlag>");
			strInputXml.append("<Comment></Comment>");
			strInputXml.append("<Owner>" + initconfigprop.getProperty("SSfolderowner") + "</Owner>");
			strInputXml.append("<OwnerType>G</OwnerType>");
			strInputXml.append("<OwnerIndex>" + initconfigprop.getProperty("SSfolderownerindex") + "</OwnerIndex>");
			strInputXml.append("<OwnerInheritanceFlag>N</OwnerInheritanceFlag>");
			strInputXml.append("</Folder>");
			strInputXml.append("</NGOChangeFolderProperty_Input>");

			sInputXml = strInputXml.toString();
			log.XMLlog("sInputXml NGOChangeFolderProperty_Input - "+sInputXml);

			serverIp = initconfigprop.getProperty("SERVERIP");
			jtsPort = Short.parseShort(initconfigprop.getProperty("JTSPORT"));
			log.servicelog("ServerIP is: " +serverIp+ "jstpot is: "+jtsPort);

			sOutputXml = IFormCallBroker.execute(sInputXml.toString(),serverIp, jtsPort);
			log.XMLlog("sOutputXml NGOChangeFolderProperty_Output - "+sOutputXml);

			xmlResponse = new DMSXmlResponse(sOutputXml);

			if (("0").equalsIgnoreCase(xmlResponse.getVal("Status"))) {
				log.servicelog("Folder Property changed Successfully ");
				return Constant.SUCCESS;
			}
			else {
				log.servicelog("Folder Property changed got failed ");
			}
		} catch (Exception e) {
			log.errorlog("Exception " + e);
			return Constant.ERROR;
		}
		return Constant.SUCCESS;
	}
}
