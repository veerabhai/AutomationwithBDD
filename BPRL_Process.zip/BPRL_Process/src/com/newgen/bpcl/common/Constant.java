package com.newgen.bpcl.common;

public class Constant {
	private Constant() {}
	public static final String SUCCESS = "Success";
	public static final String ERROR = "ERROR";
	public static final String TEXTHTML = "text/html";
	public static final String mailpid = "[Reference number]";
	public static final String mailaction = "[Action]";
	public static final String lastactionby = "[Last Action By]";
	public static final String description = "[Description]";
	public static final String initiatedon = "[Initiated On]";
	public static final String initiatedby = "[Initiated By]";
	public static final String lastactiondate = "[Last Action Date]";
	public static final String latestremarks = "[Latest Remarks]";
}