package com.newgen.bpcl.common;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
public class InitConfigProp {

	public InitConfigProp() {

	}
	private static Properties prop = new Properties();
	WSLogger log = new WSLogger();
	static {
		try {
			String directory = System.getProperty("user.dir") + File.separator + "BPCLCONFIG" + File.separator + "BPRLConfig.properties";
			File confFile = new File(directory);
			if (!confFile.exists()) {
				WSLogger.errorlog("Config.properties file absent.");
			}
			FileInputStream fis = new FileInputStream(confFile);
			prop.load(fis);
		} catch (Exception ex) {
			WSLogger.errorlog("InitConfigProp configuration not loaded "+ ex);
		}
	}

	public static String getProperty(String key) throws Exception {
		return prop.getProperty(key);
	}
}
