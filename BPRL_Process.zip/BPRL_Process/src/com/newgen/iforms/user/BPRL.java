package com.newgen.iforms.user;

import com.newgen.bpcl.common.WSLogger;
import com.newgen.iforms.custom.IFormListenerFactory;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;

public class BPRL implements IFormListenerFactory {
	WSLogger log = new WSLogger();
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("static-access")
	@Override
	public IFormServerEventHandler getClassInstance(IFormReference iformObj) {
		log.servicelog("BPCL BPRL Process ------------------------------------------------ Started");
		return new BPRLServiceImplementation();
	}

}
