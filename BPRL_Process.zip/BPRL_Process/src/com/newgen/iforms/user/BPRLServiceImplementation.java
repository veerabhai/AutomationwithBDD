package com.newgen.iforms.user;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.bpcl.common.ApiCalls;
import com.newgen.bpcl.common.Constant;
import com.newgen.bpcl.common.FolderStructure;
import com.newgen.bpcl.common.InitConfigProp;
import com.newgen.bpcl.common.WSLogger;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.iforms.EControl;
import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.xmlapi.IFormCallBroker;
import com.newgen.webclientcodebase.model.WorkdeskModel;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BPRLServiceImplementation implements IFormServerEventHandler {
	private static final long serialVersionUID = 1L;
	WSLogger log = new WSLogger();
	FolderStructure fs = new FolderStructure();
	ApiCalls api = new ApiCalls();
	static InitConfigProp initconfigprop = new InitConfigProp();
	String initiatorname = null;
	String initiatormailid = null;

	@Override
	public void beforeFormLoad(FormDef objFormDef, IFormReference objReference) {
		
		log.servicelog("Inside beforeformload");
		String query = "";
		List<List<String>> outputList = null;
		String loggedinuser = (String) objReference.getObjGeneralData().getM_strUserName();
		log.servicelog("loggedinuser name in beforeformload is :" +loggedinuser);
		String activityname = objReference.getActivityName();
		String actionval = (String) objReference.getValue("Action");
		if(activityname.equalsIgnoreCase("Initiation") && (!actionval.equalsIgnoreCase("Send Back"))) {
			String pid = objReference.getObjGeneralData().getM_strProcessInstanceId();
			objReference.setValue("pid", pid);
			query = "select email_id from bpclemployeemst where userid = '"+loggedinuser+"'";
			log.servicelog("logged in user details query is:" +query);
			try {
				outputList = objReference.getDataFromDB(query);
				log.servicelog("logged in user details query output is:" +outputList);
				if(outputList !=null && !outputList.isEmpty()) {
					initiatormailid = outputList.get(0).get(0);
					objReference.setValue("initiatorname", loggedinuser);
					objReference.setValue("initiatormailid", initiatormailid);
				}
			}catch(Exception e) {
				log.errorlog("Exception in beformload to get initiator details is:" + e);
			}
		}

		if(activityname.equalsIgnoreCase("Approver")) {
			log.servicelog("inside beforeformload of controlset");
			objReference.applyGroup("Approver");
		}
		
	}

	@Override
	public String executeCustomService(FormDef objFormDef, IFormReference objReference, String InputXml,
			String controlName, String eventType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray executeEvent(FormDef objFormDef, IFormReference objReference, String controlId, String eventType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String executeServerEvent(IFormReference iformref, String action, String actionType, String values) {
		
		log.servicelog("Inside executeserverevent for action: " +action);
		String query="";
		List<List<String>> outputList = null;
		Date date = new Date();
		SimpleDateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
		JSONArray jsonArr = new JSONArray();
		if(action.equalsIgnoreCase("pushdoctofolderstructure")) {
			log.servicelog("Inside pushdoctofolderstructure for action: " +action);
			String sessionId ="";
			try {
				String department = (String) iformref.getValue("Department");
				String country = (String) iformref.getValue("Country");
				String asset = (String) iformref.getValue("asset");
				String documenttype = (String) iformref.getValue("DocumentType");
				String year = (String) iformref.getValue("Year");
				String winame = iformref.getObjGeneralData().getM_strProcessInstanceId();
				sessionId = api.connectCabinet(iformref, "id", "validator");  //this is supervisor user
				log.servicelog("department in java is :" +department);
				log.servicelog("country in java is :" +country);
				log.servicelog("asset in java is :" +asset);
				log.servicelog("documenttype in java is :" +documenttype);
				log.servicelog("year in java is :" +year);
				log.servicelog("sessionId is :" +sessionId);
				String res = fs.FolderStructureMovement(iformref,sessionId,department,country,asset,documenttype,year,
						winame);
				log.servicelog("response from folderstructure creation is :" +res);
				return res;
			}
			catch (Exception e) {
				log.errorlog("Some error at folder structure");
			}finally {
				api.disconnectCabinet(iformref, sessionId);
			}
		}
		else if(action.equalsIgnoreCase("checkapproverlevelsubmit")) {
			String loggedinuser = (String) iformref.getObjGeneralData().getM_strUserName();
			log.servicelog("loggedinuser name in approverlevelsubmit is :" +loggedinuser);
			//String confreq = iformref.getValue("confirmationrequired").toString();
			//get mail id of the logged in user from initiatormailid
			String rowcount = values;

			String checkaproval = "";
			String department = (String) iformref.getValue("department");
			String country = (String) iformref.getValue("country");
			query = "Select approver_name from bprl_approver_mst where department = '"+department+"'"
					+ " and country = '"+country+"'";
			try {
				outputList = iformref.getDataFromDB(query);
				log.servicelog("approval check query output is:" +outputList);
				if(outputList !=null && !outputList.isEmpty()) {
					checkaproval = outputList.get(0).get(0);
					log.servicelog("approval check query output is: "+checkaproval);
				}
			}catch(Exception e) {
				log.errorlog("Exception in populatedoc is:" + e);
			}
			
			
		}else if(action.equalsIgnoreCase("checkdoccount")) {
			String pid = iformref.getObjGeneralData().getM_strProcessInstanceId();
			log.servicelog("pid is :" +pid);
			query = "select count(*) AS totaldoc from pdbdocument pd left join "
					+ "pdbfolder pf on pf.folderindex= pd.ParentFoldIndex where pf.name = '"+pid+"'";
			log.servicelog("checkdoccount query is:" +query);
			try {
				outputList = iformref.getDataFromDB(query);
				log.servicelog("checkdoccount query output is:" +outputList);
				if(outputList !=null && !outputList.isEmpty()) {
					String doccount = outputList.get(0).get(0);
					if(doccount.equalsIgnoreCase("0")) {
						return "NoDoc";
					}
				}
			}catch(Exception e) {
				log.errorlog("Exception in checkdoccount is:" + e);
				return Constant.ERROR;
			}
		}else if(action.equalsIgnoreCase("decisionHistory")) {
			decisionHistory(iformref,"");
		}
				//Code for aspose document viewer
				else if(action.equalsIgnoreCase("generateToken")) {
					log.servicelog("Inside generateToken");
					String result = odToken(iformref,actionType);
					log.servicelog("Result generateToken" + result);
					return result;
				}
				else if(action.equalsIgnoreCase("mailTrigger")) {
					try {
						log.servicelog("Inside mailTrigger");
						log.servicelog("JSON data is: " + values);
						// Escape backslashes and double quotes
						values.replace("\\", "\\\\").replace("\"", "\\\"");

						JSONParser objJsonParser = new JSONParser();
						JSONObject objJsonInput;
						String actiontaken = "";
						String initiatedby = "";
						String confirmationusergridcount = "";
						try {
							objJsonInput = (JSONObject) objJsonParser.parse(values);
							log.servicelog("json details is: "+objJsonInput);
							actiontaken=objJsonInput.get("actiontaken").toString();
					
						} catch (ParseException e1) {
							log.errorlog("Exception un callBack while parsing input json is : " + e1);
						}										  
						log.servicelog("Action taken is : " + actiontaken);
						
						String flowtype = (String) iformref.getValue("flowtype");
						String sessionId = actionType;
						log.servicelog("Inside mailTrigger sessionID is:" +sessionId);
						log.servicelog("Inside mailTrigger flowtype is:" +flowtype);

						String mailFrom = initconfigprop.getProperty("mailfrom");
						String mailTo = "";
						String mailcc = "";
						String fyimailSubject = initconfigprop.getProperty("fyisubject");
						String fyimailbody = initconfigprop.getProperty("fyimailbody");
						String fyamailSubject = initconfigprop.getProperty("fyasubject");
						String fyamailbody = initconfigprop.getProperty("fyamailbody");

						String pid = iformref.getObjGeneralData().getM_strProcessInstanceId();
						String wid = iformref.getObjGeneralData().getM_strWorkitemId();

						query = "select IntroducedBy from wfinstrumenttable where"
								+ " ProcessInstanceID = '"+pid+"' and workitemid = 1";
						outputList = iformref.getDataFromDB(query);
						log.servicelog("logged in user details query output is:" +outputList);
						if(outputList !=null && !outputList.isEmpty()) {
							initiatedby = outputList.get(0).get(0);
						}
						log.servicelog("initiatedby is:" +initiatedby);

						String initiateddate = dateformat.format(date);

						String actionval = (String) iformref.getValue("approveaction");
						String remarks = (String) iformref.getValue("remarks");
						int rowcount = Integer.parseInt(confirmationusergridcount);

						log.servicelog("Inside mailTrigger actionval is:" +actionval);
						log.servicelog("Inside mailTrigger remarks is:" +remarks);

						String loggedinusermail = "";
						String loggedinuser = (String) iformref.getObjGeneralData().getM_strUserName();
						log.servicelog("loggedinuser name in mailtrigger is :" +loggedinuser);

						query = "select email_id from bpclemployeemst where userid = '"+loggedinuser+"'";
						log.servicelog("logged in user details query is:" +query);

						outputList = iformref.getDataFromDB(query);
						log.servicelog("logged in user details query output is:" +outputList);
						if(outputList !=null && !outputList.isEmpty()) {
							loggedinusermail = outputList.get(0).get(0);
						}
					
						else if(flowtype.equalsIgnoreCase("Approver")) {
							if(iformref.getActivityName().equalsIgnoreCase("Initiation")) {
								fyamailSubject = fyamailSubject.replace(Constant.mailpid, pid);
								fyamailbody = fyamailbody.replace(Constant.mailpid, pid);
								fyamailbody = fyamailbody.replace(Constant.initiatedby, loggedinuser);
								fyamailbody = fyamailbody.replace(Constant.initiatedon, initiateddate);
								fyamailbody = fyamailbody.replace(Constant.latestremarks, remarks);

								String mailToUserName = (String) iformref.getValue("CONFIRMATIONASSIGN");
								query = "select email_id from bpclemployeemst where userid = '"+mailToUserName+"'";
								log.servicelog("logged in user details query is:" +query);
								outputList = iformref.getDataFromDB(query);
								log.servicelog("next user mail details query output is:" +outputList);
								if(outputList !=null && !outputList.isEmpty()) {
									mailTo = outputList.get(0).get(0);
								}
								mailcc = loggedinusermail;
								api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyamailSubject, fyamailbody, pid, wid);
							}
							else if (iformref.getActivityName().equalsIgnoreCase("Approver")) {
								log.servicelog("log1");
								String initiateddateval = iformref.getObjGeneralData().getM_strIntroductionDateTime();
								log.servicelog("initiateddate is: " + initiateddateval);

								SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // <-- match your actual DB format
								SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy"); // <-- your desired format

								Date dateObj = inputFormat.parse(initiateddateval); // convert String -> Date
								String initiateddateformattedval = outputFormat.format(dateObj); // convert Date -> formatted String

								log.servicelog("Formatted initiated date is: " + initiateddateformattedval);

								if(actionval.equalsIgnoreCase("Approved")) {
									log.servicelog("log2");
									fyimailSubject = fyimailSubject.replace(Constant.mailpid, pid);
									fyimailbody = fyimailbody.replace(Constant.mailaction, actionval);
									fyimailbody = fyimailbody.replace(Constant.mailpid, pid);
									fyimailbody = fyimailbody.replace(Constant.lastactionby, loggedinuser);
									fyimailbody = fyimailbody.replace(Constant.description, remarks);
									fyimailbody = fyimailbody.replace(Constant.initiatedon, initiateddateformattedval);
									fyimailbody = fyimailbody.replace(Constant.lastactiondate, dateformat.format(date));
									mailTo = (String) iformref.getValue("initiatormailid");
									mailcc = loggedinusermail;
									api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyimailSubject, fyimailbody, pid, wid);

								}
								else if(actionval.equalsIgnoreCase("Send Back")) {
									log.servicelog("log3");
									log.servicelog("log3 initiatedby is: "+ initiatedby);
									fyamailSubject = fyamailSubject.replace(Constant.mailpid, pid);
									fyamailbody = fyamailbody.replace(Constant.mailpid, pid);
									fyamailbody = fyamailbody.replace(Constant.initiatedby, initiatedby);
									fyamailbody = fyamailbody.replace(Constant.initiatedon, initiateddateformattedval);
									fyamailbody = fyamailbody.replace(Constant.latestremarks, remarks);
									mailTo = (String) iformref.getValue("initiatormailid");
									mailcc = loggedinusermail;
									api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyamailSubject, fyamailbody, pid, wid);
								}
							}
							else if (iformref.getActivityName().equalsIgnoreCase("Initiator")) {

								String initiateddateval = iformref.getObjGeneralData().getM_strIntroductionDateTime();
								log.servicelog("initiateddate is: " + initiateddateval);

								SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // <-- match your actual DB format
								SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy"); // <-- your desired format

								Date dateObj = inputFormat.parse(initiateddateval); // convert String -> Date
								String initiateddateformattedval = outputFormat.format(dateObj); // convert Date -> formatted String

								log.servicelog("Formatted initiated date is: " + initiateddateformattedval);
								fyamailSubject = fyamailSubject.replace(Constant.mailpid, pid);
								fyamailbody = fyamailbody.replace(Constant.mailpid, pid);
								fyamailbody = fyamailbody.replace(Constant.initiatedby, initiatedby);
								fyamailbody = fyamailbody.replace(Constant.initiatedon, initiateddateformattedval);
								fyamailbody = fyamailbody.replace(Constant.latestremarks, remarks);
								mailTo = (String) iformref.getValue("initiatormailid");
								mailcc = loggedinusermail;
								api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyamailSubject, fyamailbody, pid, wid);
							}
						}

							else if (iformref.getActivityName().equalsIgnoreCase("Approver")) {

								String initiateddateval = iformref.getObjGeneralData().getM_strIntroductionDateTime();
								log.servicelog("initiateddate is: " + initiateddateval);

								SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // <-- match your actual DB format
								SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy"); // <-- your desired format

								Date dateObj = inputFormat.parse(initiateddateval); // convert String -> Date
								String initiateddateformattedval = outputFormat.format(dateObj); // convert Date -> formatted String

								log.servicelog("Formatted initiated date is: " + initiateddateformattedval);

								if(actionval.equalsIgnoreCase("Confirm")) {
									fyimailSubject = fyimailSubject.replace(Constant.mailpid, pid);
									fyimailbody = fyimailbody.replace(Constant.mailaction, actionval);
									fyimailbody = fyimailbody.replace(Constant.mailpid, pid);
									fyimailbody = fyimailbody.replace(Constant.lastactionby, loggedinuser);
									fyimailbody = fyimailbody.replace(Constant.description, remarks);
									fyimailbody = fyimailbody.replace(Constant.initiatedon, initiateddateformattedval);
									fyimailbody = fyimailbody.replace(Constant.lastactiondate, dateformat.format(date));
									mailTo = (String) iformref.getValue("initiatormailid");
									mailcc = loggedinusermail;
									api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyimailSubject, fyimailbody, pid, wid);

								}
								else if(actionval.equalsIgnoreCase("Send Back")) {
									fyamailSubject = fyamailSubject.replace(Constant.mailpid, pid);
									fyamailbody = fyamailbody.replace(Constant.mailpid, pid);
									fyamailbody = fyamailbody.replace(Constant.initiatedby, initiatedby);
									fyamailbody = fyamailbody.replace(Constant.initiatedon, initiateddateformattedval);
									fyamailbody = fyamailbody.replace(Constant.latestremarks, remarks);
									mailTo = (String) iformref.getValue("initiatormailid");
									mailcc = loggedinusermail;
									api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyamailSubject, fyamailbody, pid, wid);
								}
							}
							else if (iformref.getActivityName().equalsIgnoreCase("Approver Send Back")) {

								String initiateddateval = iformref.getObjGeneralData().getM_strIntroductionDateTime();
								log.servicelog("initiateddate is: " + initiateddateval);

								SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // <-- match your actual DB format
								SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy"); // <-- your desired format

								Date dateObj = inputFormat.parse(initiateddateval); // convert String -> Date
								String initiateddateformattedval = outputFormat.format(dateObj); // convert Date -> formatted String

								log.servicelog("Formatted initiated date is: " + initiateddateformattedval);

								if(actiontaken.equalsIgnoreCase("Archived")) {
									fyimailSubject = fyimailSubject.replace(Constant.mailpid, pid);
									fyimailbody = fyimailbody.replace(Constant.mailaction, "Archived");
									fyimailbody = fyimailbody.replace(Constant.mailpid, pid);
									fyimailbody = fyimailbody.replace(Constant.lastactionby, loggedinuser);
									fyimailbody = fyimailbody.replace(Constant.description, remarks);
									fyimailbody = fyimailbody.replace(Constant.initiatedon, initiateddateformattedval);
									fyimailbody = fyimailbody.replace(Constant.lastactiondate, dateformat.format(date));
									mailcc = loggedinusermail;
									for(int i = 0; i<rowcount; i++) {
										String userforconf = iformref.getTableCellValue("table8", i,0);
										query = "select email_id from bpclemployeemst where userid = '"+userforconf+"'";
										log.servicelog("childWI user mail query is:" +query);
										outputList = iformref.getDataFromDB(query);
										log.servicelog("childWI user mail details query output is:" +outputList);
										if(outputList !=null && !outputList.isEmpty()) {
											mailTo = outputList.get(0).get(0);
										}
										api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyamailSubject, fyamailbody, pid, wid);
									}
								}else {
									fyamailSubject = fyamailSubject.replace(Constant.mailpid, pid);
									fyamailbody = fyamailbody.replace(Constant.mailpid, pid);
									fyamailbody = fyamailbody.replace(Constant.initiatedby, initiatedby);
									fyamailbody = fyamailbody.replace(Constant.initiatedon, initiateddateformattedval);
									fyamailbody = fyamailbody.replace(Constant.latestremarks, remarks);
									mailcc = loggedinusermail;

									query = "select var_str2 from wfinstrumenttable where ProcessInstanceID = '"+pid+"'"
											+ " and workitemid != '1'";
									log.servicelog("query to check available conf users is:" +query);
									outputList = iformref.getDataFromDB(query);
									log.servicelog("available conf users are:" +outputList);
									for(int i = 0; i<outputList.size(); i++) {
										String userforconf = outputList.get(i).get(0);
										query = "select email_id from bpclemployeemst where userid = '"+userforconf+"'";
										log.servicelog("childWI user mail query is:" +query);
										outputList = iformref.getDataFromDB(query);
										log.servicelog("childWI user mail details query output is:" +outputList);
										if(outputList !=null && !outputList.isEmpty()) {
											mailTo = outputList.get(0).get(0);
										}
										api.mailTrigger(iformref,sessionId, mailTo, mailFrom, mailcc, fyamailSubject, fyamailbody, pid, wid);
									}
								}
							}
						}
					//}
					catch(Exception e) {
						log.errorlog("Exception in mailtrigger is:" + e);
					}
				}
		
		
		
		
		return null;
		
	}

	
	
	
	public  String generateOdToken(IFormReference arg0,String sessionId) {
		String outputXml = "";
		try {
			String inputXml =
					"<?xml version=\"1.0\"?>" +
							"<NGOManageToken_Input>" +
							"<Option>NGOManageToken</Option>" +
							"<CabinetName>" + arg0.getCabinetName() + "</CabinetName>" +
							"<TokenValue>" + sessionId + "</TokenValue>" +
							"<ActionFlag>G</ActionFlag>" +
							"</NGOManageToken_Input>";
			log.XMLlog("Input xml of NGOManageToken_Input:- "+ inputXml);

			outputXml = IFormCallBroker.execute(inputXml.toString(), arg0.getObjGeneralData().getM_strJTSIP(), 
					Integer.parseInt(arg0.getObjGeneralData().getM_strJTSPORT()));
			log.XMLlog("Output xml of NGOManageToken_Output:-" +outputXml);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return outputXml;
	}
	
	public String odToken(IFormReference arg0,String sessionId) {
		String token = "";
		DMSXmlResponse xmlResponse = null;
		String outputXml = generateOdToken(arg0,sessionId);
		xmlResponse = new DMSXmlResponse(outputXml);
		log.servicelog("xmlResponse" + xmlResponse);

		if (xmlResponse.getVal("Status").equalsIgnoreCase("0")) {
			token = xmlResponse.getVal("TokenValue");
		}
		return token;
	}
	
	
	@SuppressWarnings("static-access")
	public int decisionHistory(IFormReference iformref, String action) {

		log.servicelog("inside decisionHistory");
		String query = "";
		String actionval = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		String currentDateTime = sdf.format(new Date());
		String activityname = iformref.getActivityName();
		String pid = iformref.getObjGeneralData().getM_strProcessInstanceId();
		String loggedinuser = (String) iformref.getObjGeneralData().getM_strUserName();
		if(activityname.equalsIgnoreCase("Initiation")) {
			actionval = (String) iformref.getValue("Actionr");
		}else {
			actionval = (String) iformref.getValue("Action");
		}
		String dateval = currentDateTime;
		String remarks = (String) iformref.getValue("remarks");
		remarks = remarks.replace("'", "''");
	
		log.servicelog("pid is:" +pid);
		log.servicelog("loggedinusername is:" +loggedinuser);
		log.servicelog("actionvalue is:" +actionval);
		log.servicelog("actiondate is:" +dateval);
		log.servicelog("remarks is:" +remarks);
		log.servicelog("activityname is:" +activityname);

		if(activityname.equalsIgnoreCase("Initiator")) {
			query = "insert into bprl_historyactiontbl (mapid,username, useraction, actiondate, remarks) "
					+ "values ('"+pid+"','"+loggedinuser+"','Initiated','"+dateval+"',N'"+remarks+"')";
		}
		/*
		 * else if(action.equalsIgnoreCase("Archived")) { query =
		 * "insert into ssactionhistory (mapid, username, useraction, date, remarks) " +
		 * "values ('"+pid+"','"+loggedinuser+"','Archived','"+
		 * dateval+"','The case has been archived by the Initiator.')"; }
		 */
		/*
		 * else if(activityname.equalsIgnoreCase("Initiation")) { query =
		 * "insert into ssactionhistory (username, useraction, date, remarks) " +
		 * "values ('"+loggedinuser+"','Reinitiated','"+dateval+"',N'"+remarks+"')"; }
		 */
		else {
			query = "insert into bprl_historyactiontbl (mapid, username, useraction, actiondate, remarks) "
					+ "values ('"+pid+"','"+loggedinuser+"','"+actionval+"','"+dateval+"',N'"+remarks+"')";
		}
		log.servicelog("insert decision history query is:" +query);
		try {
			int responseval = iformref.saveDataInDB(query);
			log.servicelog("decision query output is:" +responseval);
			return responseval;
		}catch(Exception e) {
			log.errorlog("Exception in decisionHistory is:" + e);
			return -1;
		}
	}
	
	
	@Override
	public String generateHTML(EControl objControl) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomFilterXML(FormDef objFormDef, IFormReference objReference, String variableName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String introduceWorkItemInWorkFlow(IFormReference objReference, HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String introduceWorkItemInWorkFlow(IFormReference objReference, HttpServletRequest request,
			HttpServletResponse response, WorkdeskModel wdmodel) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String onChangeEventServerSide(IFormReference objReference, String controlId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String postHookExportToPDF(IFormReference objReference, File f) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void postHookOnDocumentOperations(IFormReference objReference, String controlId, String docType,
			int docImageIndex, String operationType) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void postHookOnDocumentUpload(IFormReference objReference, String controlId, String docType, File f,
			int docImageIndex) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String setMaskedValue(String FieldName, String currentVal) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateDataInWidget(IFormReference objReference, String WidgetName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String validateDocumentConfiguration(String controlId, String docType, File f, Locale locale) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef objFormDef, IFormReference objReference, String eventType) {
		// TODO Auto-generated method stub
		return null;
	}

}
